import RouteNav from "../components/RouteNav"

function Login() {
    return (
        <>
            <RouteNav />
            <div className="container mt-5 d-flex justify-content-center align-items-center h-600 flex-column">
                <form action="/#" method="POST" className="form col-5 border p-2 d-flex justify-content-center align-items-center flex-column shadow rounded">
                    <div className="float-start">
                        <div className="form-group my-2">
                            <label className="col-4 mb-1">Username:</label>
                            <input type="text" name="username" placeholder="Username" className="form-control"/>
                        </div>
                        <div className="form-group my-2">
                            <label className="col-4 mb-1">Password:</label>
                            <input type="password" name="password" placeholder="Password" className="form-control"/>
                        </div>
                    </div>
                    <div className="row mt-2 w-400">
                        <button type="submit" className="btn bg-primary text-white col mx-1" >Create</button>
                        <input type="submit" className="btn bg-primary text-white col mx-1" value="Log in"/>
                    </div>
                </form>
                
                
            </div>
        </>
    )
}

export default Login
