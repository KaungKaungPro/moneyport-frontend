import RouteNav from "../components/RouteNav"
import {useEffect, useState} from "react";
import axios from 'axios';

async function loadData() {
  try {
    const response = await axios.get('http://localhost:8080/api/learn/forum');
    return response.data;
  } catch (error) {
    throw new Error('Failed to fetch data from the endpoint');
  }
}

function Forum() {
    let [list, setList] = useState([]);
    let [content, setContent] = useState("");
    useEffect(() => {
        const fetchData = async () => {
          try {
            const response = await loadData();
            setList(response);
          } catch (err) {
            console.log(err);
          }
        };
        fetchData();
      }, []);
    const handleChange = (e) => {
        setContent(e.target.value);
    };
    async function submit(){
        if(!content || content.trim().length===0){
            alert('Please enter a description of your problem')
            return;
        }
      try {
        let response = await axios.post('http://localhost:8080/api/learn/question/add',{content:content});
        if(response.status===200){
         try {
             setContent("");
            response = await loadData();
            setList(response);
          } catch (err) {
            console.log(err);
          }
        }
      } catch (error) {
        window.alert(error.response.data.msg);
      }
    }
    async function remove(e){
        if(!window.confirm("Are you sure delete this question?")){
            return;
        }
        const id=e.target.dataset.id;
        try {
            let response = await axios.get('http://localhost:8080/api/learn/question/del-'+id);
            if(response.status===200){
            try {
                response = await loadData();
                setList(response);
            } catch (err) {
                console.log(err);
            }
            }
        } catch (error) {
            console.log(error);
        }
    }
    return (
        <>
            <RouteNav/>
            <div className="lc_main">
                <div className="form-group">
                    <label htmlFor="question">Question</label>
                    <textarea name="content" rows="5" cols="50" id="question" value={content} onChange={handleChange} className="form-control" placeholder="Please enter a description of your problem"></textarea>
                </div>
                <div className="pull-right">
                    <button type="button" className="btn btn-primary" onClick={submit}>Add Question</button>
                </div>
                <div className="new_list clearfix">
                    {list.map((item, index) => (
                        <div key={index}>
                            <input type="button" value="Delete" data-id={item.id} onClick={remove}/>
                            <a href={'/question/' + item.id}>
                                <div className="panel panel-info" key={index}>
                                    <div className="panel-body">{item.content}</div>
                                    <div className="text_r m10">
                                        <span className="ml50">{item.createTime}</span>
                                    </div>
                                </div>
                            </a>
                        </div>
                    ))}
                </div>
            </div>
        </>
    )
}

export default Forum
