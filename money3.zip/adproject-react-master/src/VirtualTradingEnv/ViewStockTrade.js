import { useEffect, useState } from "react"
import $ from 'jquery'
import LineChart from "./VtComponents/LineChart";
import { useParams } from "react-router-dom";
import RouteTitle from "../components/RouteTitle";
import TradeInstruction from "./VtComponents/TradeInstruction";
import { useUserContext } from "./VTELayout";

function ViewStockTrade(props) {

    const [stockTrades, setStockTrade] = useState([]);
    const [timeLabels, setTimeLabels] = useState([]);
    const [errorComp, setErrorComp] = useState(null);
    const { stockCode } = useParams();
    const { userId } = useUserContext();

    const [buyQuantity, setBuyQuantity] = useState(0);
    const [sellQuantity, setSellQuantity] = useState(0);

    const [tradeInstructions, setTradeInstructions] = useState([]);

    useEffect(() => {
        return () => { 
            $.ajax({
                url: `http://localhost:8080/api/vt/viewStock1D/${userId}/${stockCode}`,
                method: "GET",
                success: (res) => { 
                    if (res.length > 0) {
                        setStockTrade(res.map(t => t.price));
                        setTimeLabels(res.map(t => t.timeTraded))
                        setErrorComp(null);
                    } else { 
                        setStockTrade([]);
                    }
                },
                error: (err) => { 
                    setErrorComp(<>
                        <p>Stock trades did not load successfully.</p>
                    </>)
                    
                }
            })
        }

    }, [stockCode, userId]);
    
    function handleView(url, yMapper, labelMapper) { 
        return () => {
            $.ajax({
            url: url,
            method: "GET",
            success: (res) => {
                if (res.length > 0) {
                    setStockTrade(res.map(yMapper));
                    setTimeLabels(res.map(labelMapper))
                    setErrorComp(null);
                } else {
                    setStockTrade([]);
                }
            },
            error: (err) => {
                setErrorComp(<>
                    <p>Stock trades did not load successfully.</p>
                </>)   
            }
        });
        };
    }

    function handleBuy() { 
        if (window.confirm("Confirm buy?")) { 
            $.ajax({
                url: ``,
                method: "POST",
                data: {
                    buy: stockCode,
                    quantity: buyQuantity
                },
                success: (res) => { 
                    console.log(res);
                    setTradeInstructions(res);
                },
                error: (err) => { 
                    console.log(err);
                }
            })
        }
    }

    function handleSell() { 
        if (window.confirm("Confirm sell?")) { 
            $.ajax({
                url: ``,
                method: "POST",
                data: {
                    buy: stockCode,
                    quantity: sellQuantity
                },
                success: (res) => { 
                    console.log(res);
                    setTradeInstructions(res);
                },
                error: (err) => { 
                    console.log(err);
                }
            })
        }
    }

    return (
        <div>
            <div className="w-100 p-4">
                <RouteTitle title="Stock Information"/>
                <div className="row">
                    <div className="col-9">
                        <div className="d-flex flex-row p-2">
                            <button className="btn me-2 underline text-primary fs-4" onClick={handleView(`http://localhost:8080/api/vt/viewStock1D/${userId}/${stockCode}`, t=>t.price, t => t.timeTraded)}>1d</button>
                            <button className="btn me-2 underline text-primary fs-4" onClick={handleView(`http://localhost:8080/api/vt/viewStock1W/${userId}/${stockCode}`, t=>t.close, t => t.dateTraded)}>1w</button>
                            <button className="btn me-2 underline text-primary fs-4" onClick={handleView(`http://localhost:8080/api/vt/viewStock1M/${userId}/${stockCode}`, t=>t.close, t => t.dateTraded)}>1m</button>
                            <button className="btn me-2 underline text-primary fs-4" onClick={handleView(`http://localhost:8080/api/vt/viewStock1Y/${userId}/${stockCode}`, t=>t.close, t => t.dateTraded)}>1y</button>
                        </div>
                        { stockTrades && <LineChart chartData={{
                        labels: timeLabels,
                        datasets: [
                            {
                                label: "Price",
                                data: stockTrades,
                                tension: 0.1
                            }
                        ]
                    }} title={`Stock ${stockCode}`} options={{
                        elements: {
                            point: {
                                pointStyle: false
                            },
                            line: {
                                borderColor: 'blue',
                                backgroundColor: 'white',
                                borderWidth: 1.5
                            }
                        }
                    }} />}
                    </div>
                    <div className="col-3">
                        <div className="row border h-50">
                            <div className="row p-1">
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Open</b></span>
                                    <span className="ms-2">6.51</span>
                                </div>
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Market Cap</b></span>
                                    <span className="ms-2">11B</span>
                                </div>
                            </div>
                            <div className="row p-1">
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Volume</b></span>
                                    <span className="ms-2">1376000</span>
                                </div>
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Dividend</b></span>
                                    <span className="ms-2">1.2%</span>
                                </div>
                            </div>
                            <div className="row p-1">
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>PE Ratio</b></span>
                                    <span className="ms-2">26.52</span>
                                </div>
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>EPS</b></span>
                                    <span className="ms-2">11B</span>
                                </div>
                            </div>
                            <div className="row p-1">
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Day Range</b></span>
                                    <span className="ms-2">6.49</span>
                                </div>
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Earning Date</b></span>
                                    <span className="ms-2">11B</span>
                                </div>
                            </div>
                            <div className="row p-1">
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>Revenue</b></span>
                                    <span className="ms-2">$2730000</span>
                                </div>
                                <div className="col d-flex flex-row justify-content-start">
                                    <span className="ms-2"><b>EBITDA</b></span>
                                    <span className="ms-2">6.12</span>
                                </div>
                            </div>
                        </div>
                        <div className="row mt-2">
                            <div className="col h-100 border">
                                <div className="row">
                                    <form onSubmit={ handleBuy } className="form d-flex flex-row justify-content-start align-items-center my-2">
                                        <label className="me-2">Buy {stockCode}</label>
                                        <input type="number" onChange={(e) => { setBuyQuantity(e.target.value) }} className="form-control me-2 w-50" />
                                        <input type="submit" value="Buy" className="btn bg-primary text-white"/>
                                    </form>
                                </div>
                                <div className="row">
                                    <form onSubmit={ handleSell } className="form d-flex flex-row justify-content-start align-items-center my-2">
                                        <label className="me-2">Sell {stockCode}</label>
                                        <input type="number" onChange={(e) => { setSellQuantity(e.target.value) }} className="form-control me-2 w-50" />
                                        <input type="submit" value="Sell" className="btn bg-primary text-white"/>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div className="row mt-2 p-2 border">
                            <div className="fs-6 align-start"><b>Current trade instruction for {stockCode}</b></div>
                            {tradeInstructions && tradeInstructions.map(ti => <TradeInstruction ti={ti} />)}
                            {!tradeInstructions && <span>No trade instructions for { stockCode }</span>}
                        </div>
                </div>
            </div>
            </div>
            { errorComp ? errorComp : <></>}
        </div>
    )
}

export default ViewStockTrade
