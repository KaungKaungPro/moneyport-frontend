import { useEffect, useState } from "react"
import $ from 'jquery'
import { Link } from "react-router-dom";
import RouteTitle from "../components/RouteTitle";
import { useUserContext } from "./VTELayout";
import Loader from "../components/Loader";


function TradeDashboard() {
    const [loading, setLoading] = useState(false);
    const [mainBoard, setMainBoard] = useState(null);
    const { userId } = useUserContext();
    useEffect(() => {

        if (mainBoard == null) { 
            setLoading(true);
            $.ajax({
                url: `http://localhost:8080/api/vt/getMainBoardData/${userId}`,
                method: "GET",
                success: (res) => { 
                    setMainBoard(res);
                    setLoading(false);
                    console.log("success called mainboard");
                },
                error: (err) => { 
                    setLoading(false);
                    console.log("error calling getMainBoard");
                }
            });
        }
        
    }, [mainBoard, userId]);

    return (
        <>
            { loading && <Loader />}
            <div className="w-100 p-4">
                <RouteTitle title="Virtual Trade - Mainboard"/>
                <div className="row mt-3">
                    <div className="col border me-2"></div>
                    <div className="col overflow-auto vh-50">
                        <table className="table p-3">
                            <thead>
                                <tr>
                                    <th className="col-1">Stock Code</th>
                                    <th className="col-2">Stock Name</th>
                                    <th className="col-1">Open</th>
                                    <th className="col-1">Close</th>
                                    <th className="col-1">High</th>
                                    <th className="col-1">Low</th>
                                </tr>
                            </thead>
                            <tbody className="overflow-auto">
                                {
                                        mainBoard && mainBoard.stockData && mainBoard.stockData.map((sd, i, _) =>
                                            <tr key={sd.stock.stockCode}>
                                                <td className="fs-8"><Link to={ `/vte/viewStockTrade/${sd.stock.stockCode}` }>{sd.stock.stockCode}</Link></td>
                                                <td>{sd.stock.stockName}</td>
                                                <td>{sd.open.toFixed(2)}</td>
                                                <td>{sd.close.toFixed(2)}</td>
                                                <td>{sd.high.toFixed(2)}</td>
                                                <td>{sd.low.toFixed(2)}</td> 
                                            </tr>
                                        )
                            }
                            </tbody>
                        </table>
                    </div>
                </div>
               
            </div>
        </>
    )
}

export default TradeDashboard
