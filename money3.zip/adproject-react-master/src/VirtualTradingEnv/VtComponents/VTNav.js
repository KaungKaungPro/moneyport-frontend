import { NavLink } from "react-router-dom"

function VTNav() {
    return (
        <div className="ms-4">
            <nav className="d-flex flex-row justify-content-end align-items-center">
                <NavLink to='/vte/dashboard' className="link-opacity-50-hover text-decoration-none bg-primary text-white light me-3 rounded p-2">Dashboard</NavLink>
                <NavLink to='/vte/portfolios' className="link-opacity-50-hover text-decoration-none bg-primary text-white light me-3 rounded p-2">Portfolios</NavLink>
                <NavLink to='/vte/ti' className="link-opacity-50-hover text-decoration-none bg-primary text-white me-3 rounded p-2">Pending Trades</NavLink>
            </nav>
        </div>
    )
}

export default VTNav
