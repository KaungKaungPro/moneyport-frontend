import { useEffect, useState } from "react"
import RouteTitle from "../components/RouteTitle"
import $ from 'jquery';
import Loader from "../components/Loader";

function GameDayTradeInstructions() {

    let [tradeInstructions, setTradeInstructions] = useState([]);
    let [loading, setLoading] = useState(false);

    useEffect(() => { 
        setLoading(true);
        $.ajax({
            url: `http://localhost:8080/api/vt/getCurrentTradeInstructions`,
            method: "GET",
            success: (res) => { 
                setTradeInstructions(res);
                setLoading(false);
            },
            error: (err) => { 
                console.log(err);
                setLoading(false);
            }
        });
    }, []);

    function handleRemove(id) { 
        tradeInstructions.splice(id, 1);
        console.log(tradeInstructions);
    }

    return (
    <>
        {loading && <Loader />}
        <div className="w-100 p-4">
            <RouteTitle title="Trade Instructions" />
            <table className="table">
                <thead>
                    <tr>
                            <th>Buy / Sell</th>
                            <th>Stock</th>
                            <th>Stock Code</th>
                            <th>Quantity</th>
                            <th>Bid / Ask</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {tradeInstructions && tradeInstructions.map(ti => <>
                            <tr>
                                <td>{ti.tradeOp}</td>
                                <td>{ti.stock.stockName}</td>
                                <td>{ti.stock.stockCode}</td>
                                <td>{ti.quantity}</td>
                                <td>{ti.price}</td>
                                <td><button onClick={() => handleRemove(tradeInstructions.indexOf(ti))
                                }></button></td>
                            </tr>
                        </>)}
                        {
                            !tradeInstructions && <tr>
                                <td colspan="5">
                                    There is no trade instruction yet.
                                </td>
                        </tr>
                    }
                </tbody>
            </table> 
        </div>
    </>
    )
}

export default GameDayTradeInstructions
