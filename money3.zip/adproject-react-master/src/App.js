import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';

import Home from './components/Home';
import Login from './UserAccount/Login';
import TradeDashboard from './VirtualTradingEnv/TradeDashboard';
import Terminology from './LearningCentre/Terminology'
import Forum from './LearningCentre/Forum'
import Question from './LearningCentre/Question'
import ViewStockTrade from './VirtualTradingEnv/ViewStockTrade';
import MktSimParamForm from './VirtualTradingEnv/Admin/MktSimParamForm';
import PortfolioDashboard from './VirtualTradingEnv/PortfolioDashboard';
import { VTELayout } from './VirtualTradingEnv/VTELayout';
import GameDayTradeInstructions from './VirtualTradingEnv/GameDayTradeInstructions';

import 'bootstrap/dist/css/bootstrap.min.css';

function App() {


  return (<BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="learningCentre" element={<Terminology />} />
        <Route path="/terminology" element={<Terminology />} />
        <Route path="/forum" element={<Forum />} />
        <Route path="/question/:questionId" element={<Question />} />
        <Route path="vte" element={
          <VTELayout />} >
          <Route index element={<TradeDashboard />} />
          <Route path="dashboard" element={<TradeDashboard />} />
          <Route path="ti" element={<GameDayTradeInstructions />} />
          <Route path="viewStockTrade/:stockCode" element={<ViewStockTrade />} />
          <Route path="portfolios" element={<PortfolioDashboard />} />
        </Route>
        <Route path="virtualTradingAdmin" element={<MktSimParamForm />} />
        <Route path="login" element={<Login />} />
      </Routes>
    </BrowserRouter>);
}

export default App;
