package sg.nus.iss.adproject.services;

import sg.nus.iss.adproject.entities.simulation.MktSimParam;

public interface VirtualTradeAdminInterface {

	void saveMktSimParam(MktSimParam param);
}
