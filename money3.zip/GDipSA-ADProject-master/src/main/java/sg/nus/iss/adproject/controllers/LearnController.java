package sg.nus.iss.adproject.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sg.nus.iss.adproject.entities.Answer;
import sg.nus.iss.adproject.entities.FriendLink;
import sg.nus.iss.adproject.entities.Question;
import sg.nus.iss.adproject.entities.Terminology;
import sg.nus.iss.adproject.services.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RestController
@RequestMapping(value = "/api/learn")
public class LearnController {

    @Autowired
    private FriendLinkInterface friendLinkInterface;
    @Autowired
    private TerminologyInterface terminologyInterface;
    @Autowired
    private QuestionInterface questionInterface;
    @Autowired
    private AnswerInterface answerInterface;
    @Autowired
    private SensitiveInterface sensitiveInterface;


    @GetMapping("/terminology")
    public ResponseEntity<?> learnCenter(@RequestParam(value = "term", defaultValue = "") String term) {
        List<Terminology> list = terminologyInterface.getAllTerminology(term);
        Map<String, Object> map = new HashMap<>();
        map.put("terminologies", list);
        map.put("term", term);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    @GetMapping("/forum")
    public ResponseEntity<?> forum() {
        List<Question> list = questionInterface.getAllQuestion();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

    @PostMapping(value = "/question/add")
    public ResponseEntity<?> addQuestion(@RequestBody Question question) {
        boolean has = sensitiveInterface.has(question.getContent());
        if (has) {
            Map<String, String> map = new HashMap<>();
            map.put("msg", "The content contains a sentimental word and failed to be published.");
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        question.setCreateTime(new Date());
        questionInterface.add(question);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping(value = "/question/{questionId}")
    public ResponseEntity<?> detailQuestion(@PathVariable("questionId") int questionId) {
        Question question = questionInterface.getQuestion(questionId);
        List<Answer> list = answerInterface.getAllAnswer(questionId);
        Map<String, Object> map = new HashMap<>();
        map.put("question", question);
        map.put("answers", list);
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    @GetMapping(value = "/question/del-{questionId}")
    public ResponseEntity<?> deleteQuestion(@PathVariable("questionId") int questionId) {
        questionInterface.delete(questionId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping(value = "/answer/del-{answerId}")
    public ResponseEntity<?> deleteAnswer(@PathVariable("answerId") int answerId) {
        answerInterface.delete(answerId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(value = "/answer/add")
    public ResponseEntity<?> addAnswer(@RequestBody Answer answer) {
        boolean has = sensitiveInterface.has(answer.getContent());
        if (has) {
            Map<String, String> map = new HashMap<>();
            map.put("msg", "The content contains a sentimental word and failed to be published.");
            return new ResponseEntity<>(map, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        answer.setCreateTime(new Date());
        answerInterface.add(answer);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @PostMapping(value = "/answer/upvote")
    public ResponseEntity<?> upVoteAnswer(@RequestBody Answer answer) {
        answerInterface.editUpVote(answer);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/link")
    public ResponseEntity<?> link() {
        List<FriendLink> list = friendLinkInterface.getAllFriendLink();
        return new ResponseEntity<>(list, HttpStatus.OK);
    }

}
