package sg.nus.iss.adproject.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import sg.nus.iss.adproject.entities.simulation.Stock;

public interface StockRepository extends JpaRepository<Stock, Integer>{

}
