package sg.nus.iss.adproject.services;

public interface SensitiveInterface {

    boolean has(String text);
}
