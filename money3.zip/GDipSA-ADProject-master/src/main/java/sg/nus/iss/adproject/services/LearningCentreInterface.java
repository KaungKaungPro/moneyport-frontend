package sg.nus.iss.adproject.services;

public interface LearningCentreInterface {

}
