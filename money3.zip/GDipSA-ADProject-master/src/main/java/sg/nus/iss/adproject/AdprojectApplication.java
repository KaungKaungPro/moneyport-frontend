package sg.nus.iss.adproject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import sg.nus.iss.adproject.io.ContextLoader;
import sg.nus.iss.adproject.repositories.MktSimParamRepository;
import sg.nus.iss.adproject.repositories.StockRepository;
import sg.nus.iss.adproject.repositories.UserRepository;

@SpringBootApplication
public class AdprojectApplication {
	
	@Value("${spring.jpa.hibernate.ddl-auto}")
	private String ddlauto;

	public static void main(String[] args) {
		SpringApplication.run(AdprojectApplication.class, args);
	}

	
	@Bean
	CommandLineRunner loadContext(UserRepository ur, StockRepository sr, MktSimParamRepository mspr) {
		return args -> {
			if(ddlauto.equals("create")) {
				ContextLoader cl = new ContextLoader((int)System.currentTimeMillis() % 10000000);
				cl.CreateData(ur, sr);
				
				cl.LoadFirstParam(mspr);
			}
		};
	}
}
