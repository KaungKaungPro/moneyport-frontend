package sg.nus.iss.adproject.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import jakarta.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.*;

import sg.nus.iss.adproject.entities.simulation.Stock;
import sg.nus.iss.adproject.entities.simulation.StockTrade;
import sg.nus.iss.adproject.entities.simulation.StockTradeViewMode;
import sg.nus.iss.adproject.entities.simulation.TradeInstruction;
import sg.nus.iss.adproject.services.VirtualTradeInterface;

@CrossOrigin
@RestController
@RequestMapping("/api/vt")
public class VirtualTradingController {

	@Autowired
	VirtualTradeInterface vtService;
	
	@GetMapping("/getStocks")
	public ResponseEntity<List<Stock>> getStocks(){
		return new ResponseEntity<>(vtService.getStocks(), HttpStatus.OK);
	}
	
	@PostMapping("/endTurn")
	public void endTurn(List<TradeInstruction> instructions, HttpServletResponse response){
		vtService.endTurn(instructions);
		try {
			response.sendRedirect("/getStocks");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@GetMapping("/startVirtualTrade")
	public void startVirtualTrade(HttpServletResponse response){
		vtService.startVirtualTradeEnv();
		try {
			response.sendRedirect("/getStocks");
		} catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	@GetMapping("/viewStock/{stockCode}")
	public ResponseEntity<List<StockTrade>> viewStock(@PathVariable("stockCode") String stockCode){
		System.out.println("retrieving trade data for " + stockCode );
		List<StockTrade> trades = vtService.getStockTrades(stockCode, StockTradeViewMode.intraDay);
		if(trades != null) {
			System.out.println("Found trade data: " + trades.size() + " records.");
			return new ResponseEntity<>(trades, HttpStatus.OK);
		}
		System.out.println("Error internal " + stockCode);
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("/buildSingleDayTrade")
	public void buildSingleDayTrade() {
		
		vtService.buildSingleDayTrade();
	}
}
