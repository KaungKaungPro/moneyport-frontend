package sg.nus.iss.adproject.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sg.nus.iss.adproject.entities.Question;
import sg.nus.iss.adproject.repositories.QuestionRepository;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class QuestionService implements QuestionInterface {

    @Autowired
    private QuestionRepository repository;

    @Override
    public List<Question> getAllQuestion() {
        List<Question> list = repository.findAll();
        list.sort((o1, o2) -> o2.getCreateTime().compareTo(o1.getCreateTime()));
        return list;
    }

    @Override
    @Transactional
    public void add(Question question) {
        repository.save(question);
    }

    @Override
    public Question getQuestion(int questionId) {
        Optional<Question> optional = repository.findById(questionId);
        return optional.orElse(null);
    }

    @Override
    @Transactional
    public void delete(int questionId) {
        repository.deleteById(questionId);
    }
}
