package sg.nus.iss.adproject.entities;

import java.util.*;

public class SearchObj {

	private String searchTerm;
	
	private List<InvestTerm> results;

	public SearchObj() {
		super();
		this.searchTerm = "";
		this.results = new ArrayList<InvestTerm>();
	}

	public String getSearchTerm() {
		return searchTerm;
	}

	public void setSearchTerm(String searchTerm) {
		this.searchTerm = searchTerm;
	}

	public List<InvestTerm> getResults() {
		return results;
	}

	public void setResults(List<InvestTerm> results) {
		this.results = results;
	}
	
	
	
}
