package sg.nus.iss.adproject.io;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import sg.nus.iss.adproject.entities.AssetClass;
import sg.nus.iss.adproject.entities.Role;
import sg.nus.iss.adproject.entities.User;
import sg.nus.iss.adproject.entities.simulation.MktSimParam;
import sg.nus.iss.adproject.entities.simulation.Stock;
import sg.nus.iss.adproject.repositories.MktSimParamRepository;
import sg.nus.iss.adproject.repositories.StockRepository;
import sg.nus.iss.adproject.repositories.UserRepository;

public class ContextLoader {
	
	private RandDataGenerator randGen;
	
	public ContextLoader(int seed) {
		super();
		this.randGen = new RandDataGenerator(seed);
	}
	
	public void CreateData(UserRepository ur, StockRepository sr) {
		BuildUsers(ur);
		BuildStocks(sr);
	}
	
	private void BuildUsers(UserRepository urepo) {
		User user = new User();
		user.setFirstName(randGen.genFirstName());
		user.setLastName(randGen.genLastName());
		user.setUsername(randGen.getUsernameFromFirstAndLastName(user.getFirstName(), user.getLastName()));
		user.setEmail(randGen.getEmailFromUsername(user.getUsername()));
		user.setPassword("password");
		user.setRole(Role.Ordinary);
		urepo.save(user);
		
		User admin = new User();
		admin.setFirstName(randGen.genFirstName());
		admin.setLastName(randGen.genLastName());
		admin.setUsername(randGen.getUsernameFromFirstAndLastName(admin.getFirstName(), admin.getLastName()));
		admin.setEmail(randGen.getEmailFromUsername(admin.getUsername()));
		admin.setPassword("password");
		admin.setRole(Role.Admin);
		urepo.save(admin);
	}
	
	private void BuildStocks(StockRepository srepo) {
		// Build A1 stocks
		AssetClass a1 = AssetClass.A1;
		for(int i = 0; i < 10; i++) {
			Stock stock = new Stock();
			stock.setStockCode(randGen.genStockCode());
			stock.setStockName(randGen.genStockName());
			stock.setCurrency(randGen.genCurrency());
			stock.setaClass(a1);
			stock.setOpenPrice(randGen.genPrice(a1));
			stock.setLastTradePrice(stock.getOpenPrice());
			stock.setIPOyear(randGen.genIPOYear());
			srepo.save(stock);
		}
		
		// Build A2 stocks
		AssetClass a2 = AssetClass.A2;
		for(int i = 0; i < 10; i++) {
			Stock stock = new Stock();
			stock.setStockCode(randGen.genStockCode());
			stock.setStockName(randGen.genStockName());
			stock.setCurrency(randGen.genCurrency());
			stock.setaClass(a2);
			stock.setOpenPrice(randGen.genPrice(a2));
			stock.setLastTradePrice(stock.getOpenPrice());
			stock.setIPOyear(randGen.genIPOYear());
			srepo.save(stock);
		}
		
		// Build A3 stocks
		AssetClass a3 = AssetClass.A3;
		for(int i = 0; i < 10; i++) {
			Stock stock = new Stock();
			stock.setStockCode(randGen.genStockCode());
			stock.setStockName(randGen.genStockName());
			stock.setCurrency(randGen.genCurrency());
			stock.setaClass(a3);
			stock.setOpenPrice(randGen.genPrice(a3));
			stock.setLastTradePrice(stock.getOpenPrice());
			stock.setIPOyear(randGen.genIPOYear());
			srepo.save(stock);
		}
	}
	
	public void LoadFirstParam(MktSimParamRepository mspr) {
		mspr.save(MktSimParam.initialMktSimParam());
	}

}
