package sg.nus.iss.adproject.entities.simulation;


import jakarta.persistence.*;
import sg.nus.iss.adproject.entities.User;

@Entity
public class PortfolioStock {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	private long quantity;
	
	private float purchasedPrice;
	
	@ManyToOne
	private Portfolio portfolio;
	
	@ManyToOne
	private Stock stock;
	
	public PortfolioStock(long id, long quantity, float purchasedPrice, Portfolio portfolio, Stock stock) {
		super();
		this.id = id;
		this.quantity = quantity;
		this.purchasedPrice = purchasedPrice;
		this.portfolio = portfolio;
		this.stock = stock;
	}

	public PortfolioStock() {
		
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public float getPurchasedPrice() {
		return purchasedPrice;
	}

	public void setPurchasedPrice(float purchasedPrice) {
		this.purchasedPrice = purchasedPrice;
	}

	public Stock getStock() {
		return stock;
	}

	public void setStock(Stock stock) {
		this.stock = stock;
	}
	
	
}
