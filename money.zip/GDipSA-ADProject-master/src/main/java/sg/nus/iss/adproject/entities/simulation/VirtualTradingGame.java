package sg.nus.iss.adproject.entities.simulation;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import sg.nus.iss.adproject.repositories.StockTradeRepository;


public class VirtualTradingGame {
	
	private MktSim mkt;
	
	private List<TradeInstruction> instructions;
	
	private StockTradeRepository str;
	
	private LocalDate gameDate;
	
	public VirtualTradingGame(StockTradeRepository str, MktSimParam params, List<Stock> stocks) {
		this.str = str;
		this.mkt = new MktSim(params, System.currentTimeMillis() % 10000L, stocks);
		this.gameDate = LocalDate.now();
	}
	
	public void EndTurn() {
		gameDate = gameDate.plusDays(1);
		mkt.buildNextTurn(gameDate, str, instructions);
		instructions.clear();
	}

	public MktSim getMkt() {
		return mkt;
	}

	public void setMkt(MktSim mkt) {
		this.mkt = mkt;
	}

	public List<TradeInstruction> getInstructions() {
		return instructions;
	}

	public void setInstructions(List<TradeInstruction> instructions) {
		this.instructions = instructions;
	}
	
	public void addInstructions(TradeInstruction instruction) {
		this.instructions.add(instruction);
	}
}
