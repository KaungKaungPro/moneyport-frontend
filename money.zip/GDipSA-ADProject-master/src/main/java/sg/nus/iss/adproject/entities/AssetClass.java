package sg.nus.iss.adproject.entities;

public enum AssetClass {
	A1, A2, A3
}
