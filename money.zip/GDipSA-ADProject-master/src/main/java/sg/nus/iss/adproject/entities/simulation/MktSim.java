package sg.nus.iss.adproject.entities.simulation;

import java.time.LocalDate;
import java.util.*;

import org.springframework.stereotype.Component;

import sg.nus.iss.adproject.repositories.StockTradeRepository;


public class MktSim {

	private List<Stock> stocks;
	
	private final int iterations = 480;
	
	private MktSimMode mode = MktSimMode.TurnBased;
	
	private MktSimParam params;
	
	public MktSim(MktSimParam params, long seed, List<Stock> stocks) {
		this.params = params;
		params.setSeed(seed);
		this.stocks = stocks; 
	}

	public List<Stock> getStocks() {
		return stocks;
	}
	
	public void addStock(Stock s) {
		stocks.add(s);
	}
	
	public MktSimMode getMode() {
		return mode;
	}

	public void setMode(MktSimMode mode) {
		this.mode = mode;
	}

	public MktSimParam getParams() {
		return params;
	}

	public void setParams(MktSimParam params) {
		this.params = params;
	}

	public void setStocks(List<Stock> stocks) {
		this.stocks = stocks;
	}

	// Represents the generated single day of trades across all
	// stocks
	private List<StockTrade> simSingleDaySequence() {
		List<StockTrade> totalTrades = new ArrayList<StockTrade>();
		for(int i = 0; i < iterations; i++) {
			totalTrades.addAll(perMinuteIteration(i + 1));
		}
		return totalTrades;
	}
	
	// Represents trades completed in single minute of time
	// Runs through all stocks and generate trades if there is
	private List<StockTrade> perMinuteIteration(int iter) {
		List<StockTrade> trades = new ArrayList<StockTrade>();
		System.out.println("Beginning trades ... ");
		for(Stock st : stocks) {
			List<StockTrade> stockTrades = TradeStock(st, iter);
			trades.addAll(stockTrades);
		}
		return trades;
	}
	
	private List<StockTrade> TradeStock(Stock stock, int iter) {
		List<StockTrade> stockTrades = StockTrade.GenerateTrades(stock, stock.getLastTradePrice(), params, iter);
		double lastTradePrice = stockTrades.isEmpty() ? stock.getLastTradePrice() : stockTrades.get(stockTrades.size() - 1).getPrice();
		System.out.println(stock.getStockName() + " traded " + stockTrades.size() + " times");
		stocks
		.stream()
		.filter(s -> s.getStockCode() == stock.getStockCode())
		.forEach(s -> {
			s.setLastTradePrice(lastTradePrice);
		});
		return stockTrades;
	}
	
	private void persistStockTrades(StockTradeRepository str, List<StockTrade> singleDayTrades, LocalDate asDate) {
		for(StockTrade st : singleDayTrades) {
			st.setDateTraded(asDate);
			str.save(st);
		}
	}
	
	public void buildNextTurn(LocalDate asDate, StockTradeRepository str, List<TradeInstruction> instructions) {
		buildSingleDayTrade(str, asDate);
		executeTradeInstructions(instructions);
	}
	
	public void buildSingleDayTrade(StockTradeRepository str, LocalDate asDate) {
		persistStockTrades(str, simSingleDaySequence(), asDate);
	}
	
	public void executeTradeInstructions(List<TradeInstruction> instructions) {
		// TODO: this should be called right after buildSingleDayTrade is called 
	}
	
	
}