package sg.nus.iss.adproject.entities.simulation;

public enum MktSimMode {
	TurnBased, RealTime
}
