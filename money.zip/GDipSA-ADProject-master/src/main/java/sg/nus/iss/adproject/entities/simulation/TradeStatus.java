package sg.nus.iss.adproject.entities.simulation;

public enum TradeStatus {
	Draft, Asking, Filled, Completed
}
