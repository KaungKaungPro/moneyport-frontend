package sg.nus.iss.adproject.entities;

public enum Role {
	Ordinary, Admin
}
