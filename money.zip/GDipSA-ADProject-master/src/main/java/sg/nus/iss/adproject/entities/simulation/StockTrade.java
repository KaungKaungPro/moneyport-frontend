package sg.nus.iss.adproject.entities.simulation;

import java.time.*;
import java.util.*;

import jakarta.persistence.*;



@Entity
public class StockTrade {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	
	@ManyToOne(fetch=FetchType.EAGER)
	private Stock stock;
	
	private double price;
	
	private long volume;
	
	private LocalDate dateTraded;
	
	private LocalTime timeTraded;
	
	private TradeStatus status;

	public StockTrade(Stock stock, double price, long volume) {
		super();
		this.stock = stock;
		this.price = price;
		this.volume = volume;
		this.dateTraded = LocalDate.now();
		this.timeTraded = LocalTime.now();
		this.status = TradeStatus.Completed;
	}

	public StockTrade(Stock stock, double price, long volume, LocalTime timeTraded, LocalDate dateTraded) {
		super();
		this.stock = stock;
		this.price = price;
		this.volume = volume;
		this.timeTraded = timeTraded;
		this.dateTraded = dateTraded;
		this.status = TradeStatus.Completed;
	}
	
	public StockTrade() {}
	
	public Stock getStock() {
		return stock;
	}

	public void setStockCode(Stock stock) {
		this.stock = stock;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public long getVolume() {
		return volume;
	}

	public void setVolume(long volume) {
		this.volume = volume;
	}

	public LocalTime getTimeTraded() {
		return timeTraded;
	}

	public void setTimeTraded(LocalTime timeTraded) {
		this.timeTraded = timeTraded;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDate getDateTraded() {
		return dateTraded;
	}

	public void setDateTraded(LocalDate dateTraded) {
		this.dateTraded = dateTraded;
	}
	
	public int getYear() {
		return dateTraded.getYear();
	}

	public TradeStatus getStatus() {
		return status;
	}

	public void setStatus(TradeStatus status) {
		this.status = status;
	}

	public static StockTrade GenerateTrade(Stock stock, double currentPrice, MktSimParam params, int iter) {
		StockTrade trade = new StockTrade(stock, currentPrice * params.genPriceVariation(stock.getaClass()), params.genTradeVolume(stock.getaClass()) * 1000);
		int hour = 9 + iter / 60;
		int minute = iter % 60;
		trade.setTimeTraded(LocalTime.of(hour, minute));
		return trade;
	}
	
	public static List<StockTrade> GenerateTrades(Stock stock, double currentPrice, MktSimParam params, int iter){
		int count = params.genTradeCount(stock.getaClass());
		List<StockTrade> trades = new ArrayList<StockTrade>();
		for(int i : new int[count]) {
			trades.add(GenerateTrade(stock, currentPrice, params, iter));
		}
		return trades;
	}
	
	@Override
	public String toString() {
		return "Stock " + stock.getStockCode() + " traded " + volume + " shares, at $" + price + " at " + timeTraded.toString();  
	}
}
