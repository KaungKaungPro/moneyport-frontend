package sg.nus.iss.adproject.services;

import sg.nus.iss.adproject.entities.FriendLink;

import java.util.List;

public interface FriendLinkInterface {

    List<FriendLink> getAllFriendLink();
}
