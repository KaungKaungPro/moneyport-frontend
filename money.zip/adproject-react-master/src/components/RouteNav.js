import {Link, NavLink} from "react-router-dom"
import {useState} from "react";

function RouteNav() {
    const [showMenu, setShowMenu] = useState(false);

    return (
    <header className="h-100 shadow">
      <nav className="d-flex flex-direction-row bg-dark">
        <div className="navbar  p-4 navbar-expand-lg w-100">
          <h1 className="text-white">MoneyPort</h1>
          <NavLink to='/' className="link-opacity-50-hover ms-4 text-decoration-none text-white">Home</NavLink>
            <NavLink to='/learningCentre' className="link-opacity-50-hover ms-4 text-decoration-none text-white"
            onMouseEnter={() => setShowMenu(true)}
            onMouseLeave={() => setShowMenu(false)}>
                Learning Centre
                {showMenu && (
                <div className="subNav">
                    <div className="item"><Link to="/terminology">Terminology</Link></div>
                    <div className="item"><Link to="/forum">Forum</Link></div>
                </div>
                )}
            </NavLink>
            <NavLink to='/vte' className="link-opacity-50-hover ms-4 text-decoration-none text-white">Virtual
                Trading</NavLink>
            <NavLink to='/virtualTradingAdmin' className="link-opacity-50-hover ms-4 text-decoration-none text-white">VT Admin</NavLink>
        </div>  
        <div className="w-25 d-flex justify-content-end align-items-center flex-direction-row">
            
            <NavLink to='/login' className="link-opacity-50-hover text-decoration-none text-white float-end bg-dark me-3">Log in</NavLink>
        </div>
      </nav>
    </header>
    )
}

export default RouteNav
