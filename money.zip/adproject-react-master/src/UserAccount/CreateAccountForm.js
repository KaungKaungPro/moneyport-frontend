

function CreateAccountForm() {

    function handleSubmitCreateAccount() { 


    }

    return (
        <div>
            <form onSubmit={handleSubmitCreateAccount}>
                


            </form>
        </div>
    )
}

export default CreateAccountForm
