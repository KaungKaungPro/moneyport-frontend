import RouteNav from "../components/RouteNav"
import {useEffect, useState} from "react";
import axios from 'axios';

async function loadData(term) {
  try {
    const response = await axios.get('http://localhost:8080/api/learn/terminology?term='+term);
    return response.data;
  } catch (error) {
    throw new Error('Failed to fetch data from the endpoint');
  }
}

function Terminology() {
    let [list, setList] = useState([]);
    let [term, setTerm] = useState("");
    useEffect(() => {
        const fetchData = async () => {
          try {
            const response = await loadData(term);
            setTerm(response.term);
            setList(response.terminologies);
          } catch (err) {
            console.log(err);
          }
        };
        fetchData(term);
      }, []);

    const handleChange = (e) => {
        setTerm(e.target.value);
    };
    async function search(){
        const response = await loadData(term);
        setTerm(response.term);
        setList(response.terminologies);
    }
    return (
        <>
            <RouteNav/>
            <div className="lc_main">
                <div className="mb10">
                    <div className="text clearfix">
                        <div className="pc_search">
                            <input type="text" name="term" value={term} placeholder="Please enter a keyword term" onChange={handleChange}/>
                            <input className="btn" type="button" value="" onClick={search}/>
                        </div>
                    </div>
                </div>
                {list.map((item, index) => (
                <div className="panel panel-info" key={index}>
                    <div className="panel-heading">
                        <h3 className="panel-title">
                            <span>{item.term}</span>
                        </h3>
                    </div>
                    <div className="panel-body">{item.definition}</div>
                </div>
                ))}
            </div>
        </>
    )
}

export default Terminology
