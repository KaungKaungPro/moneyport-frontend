import VTNav from "./VTNav"

function GameStatusBar() {

    function handleEndTurn() { 
        
    }

    return (
        <div className="d-flex flex-row justify-content-between align-items-center w-100">
            <div className="d-flex flex-row p-4 justify-content-start w-75">
                <h4>{Date().split(" ").slice(0, 4).join(" ")}</h4>
                <span className="ms-4 mt-1">Game Day 1</span>
                <span className="ms-4 mt-1">Portfolio Value: $100 000</span>
                <VTNav />    
            </div>
            <button className="me-4 btn bg-primary text-white" onClick={ handleEndTurn }>End Turn</button>
            
        </div>
    )
}

export default GameStatusBar
