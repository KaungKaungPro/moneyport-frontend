function TradeInstruction({ ti }) {


    function handleRemove() { 
        
    }

    return (
        <div className="d-flex flex-row justify-content-start align-item-center">
            <span className="me-2">ti.tradeOp</span>
            <span className="me-2">ti.quantity</span>
            <span className="me-2">ti.price</span>
            <button onClick={handleRemove}>Delete</button>
        </div>
    )
}

export default TradeInstruction
