import { useEffect, useState } from "react";
import GameStatusBar from "./VtComponents/GameStatusBar"
import RouteNav from "../components/RouteNav"
import RouteTitle from "../components/RouteTitle"
import Loader from "../components/Loader";
import $ from "jquery";
import { useParams } from "react-router-dom";
import PieChart from "./VtComponents/PieChart";

const pfl = [
    {
        vDollar: 36750,
        portfolioName: "R1 portfolio",
        portfolioStocks: [
            {
                id: 1,
                stock: {
                    id: 1,
                    stockCode: 'JNJ',
                    stockName: "Johnson & Johnson",
                    aClass: 1
                },
                quantity: 2000,
                purchasedPrice: 159.33,
                value: 2000 * 159.33,
                lastTradeDate: Date('2024-07-25')
            },
            {
                id: 2,
                stock: {
                    id: 3,
                    stockCode: 'KOF',
                    stockName: "Coca Cola",
                    aClass: 1
                },
                quantity: 3000,
                purchasedPrice: 87.75,
                value: 3000 * 87.75,
                lastTradeDate: Date('2024-07-26')
            },
        ]
    },
];


function PortfolioDashboard({ props }) {

    let [portfolios, setPortfolios] = useState([]);
    let { userId } = useParams();
    let [loading, setLoading ] = useState(false);


    useEffect(() => {
        setLoading(true);
        $.ajax({
            // url: `http://localhost:8080/api/vt/getPortfolios/${userId}`,
            url: `http://localhost:8080/api/vt/getPortfolios/1`,
            method: "GET",
            success: (res) => {
                console.log(res);
                setPortfolios(pfl);
                setLoading(false);
            },
            error: (err) => {
                console.log(err);
                setPortfolios(pfl);
                setLoading(false);
            }
        });

    }, [portfolios, userId]);

    return (
        <>
            {loading && <Loader />}
            <div>
                <div className="w-100 p-4">
                    <RouteTitle title="My Portfolios" />
                    <div className="row">
                        <div className="col">
                            {portfolios && 
                                portfolios.map(pf =>
                                    <>
                                        <h4>{ pf.portfolioName }</h4>
                                        <table className="table w-100">
                                            <thead>
                                                <tr>
                                                    <th>Stock</th>
                                                    <th>Value</th>
                                                    <th>Last Trade Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {pf.portfolioStocks.map(ps =>
                                                    <tr>
                                                        <td>{ps.stock.stockName}</td>
                                                        <td>{ps.value}</td>
                                                        <td>{ps.lastTradeDate.split(" ").slice(0,3).join(" ") }</td>
                                                    </tr>
                                                )}
                                            </tbody>
                                        </table>
                                    </>)
                            }
                        </div>
                        <div className="col border">
                            {portfolios && portfolios.map(pf => <PieChart
                                chartData={{
                                    labels: [...pf.portfolioStocks.map(ps => ps.stock.stockName)],
                                    datasets: [
                                        {
                                            label: "ABC",
                                            data: [...pf.portfolioStocks.map(ps => ps.value)],
                                        }
                                    ]
                                }}
                                options={{}}
                                title={pf.portfolioName}
                            />)}
                        </div>
                    </div>
                    
                </div>
            </div>
        </>
    )
}

export default PortfolioDashboard
