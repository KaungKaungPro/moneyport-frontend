import { Outlet } from "react-router-dom"
import style from "./VTELayout.module.css"
import RouteNav from "../components/RouteNav"
import GameStatusBar from "./VtComponents/GameStatusBar"
import Loader from "../components/Loader"
import { createContext, useContext, useEffect, useState } from "react"
import $ from "jquery"


const TIContext = createContext();
const UserContext = createContext();

function VTELayout() {
    let [userId, setUserId] = useState(null);
    let [loading, setLoading] = useState(false);

    useEffect(() => {
        if (!userId) { 
            setLoading(true);
            $.ajax({
                url: `http://localhost:8080/api/user/`,
                method: "GET",
                success: (uid) => {
                    setUserId(uid);
                    console.log(`Success getting uid!`);
                },
                error: (err) => {
                    console.log(`Error! ${err}`);
                }
            }).then((user) => { 
                console.log("Calling to start virtual trade");
                $.ajax({
                url: `http://localhost:8080/api/vt/startVirtualTrade`,
                method: "GET",
                data: {
                    userId: user.id
                },
                success: (res) => { 
                    console.log(`called success ${user}`);
                    setLoading(false);
                },
                error: (err) => { 
                    console.log(err);
                    setLoading(false);
                }
                });
            });
        }
     }, [userId]);


    return (
        <UserContext.Provider value={{
            userId: userId
            }}>
            <TIContext.Provider value={{
                tradeInstructions: []
            }}>
                <div style={style.app}>
                    { loading && <Loader />}
                    <RouteNav />
                    <GameStatusBar />
                    <Outlet />
                </div>
            </TIContext.Provider>
        </UserContext.Provider>
    )
}

function useUserContext() { 
    const context = useContext(UserContext);
    return context;
}

function useTIContext() { 
    const context = useContext(TIContext);
    return context;
}

export {VTELayout, useUserContext, useTIContext } ;
